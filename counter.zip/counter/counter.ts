import { Component } from '@angular/core';

@Component({
  selector: 'app-counter',
  imports: [],
  templateUrl: './counter.html',
  styleUrl: './counter.css'
})
export class Counter {

  count: number = 0;

  handleCounter(val: string) {
    if (val === 'increment') {
      this.count++;
    } else if (val === 'decrement') {
      if (this.count == 0) {
        this.count = 0;
      } else {
        this.count--;
      }
    } else {
      this.count = 0;
    }
  }

  // increment() {
  //   this.count++;
  // }
  // decrement(){
  //   this.count--;
  // }
  // reset(){
  //   this.count = 0;
  // }

}
